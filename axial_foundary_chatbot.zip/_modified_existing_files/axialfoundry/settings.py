from __future__ import annotations

import os
from pathlib import Path

import dj_database_url
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / '.env')


def env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {'1', 'true', 'yes', 'on'}


def env_list(name: str, default: str = '') -> list[str]:
    value = os.getenv(name, default)
    return [item.strip() for item in value.split(',') if item.strip()]


SECRET_KEY = os.getenv('SECRET_KEY', 'django-insecure-change-me')
DEBUG = env_bool('DEBUG', False)
ALLOWED_HOSTS = env_list('ALLOWED_HOSTS', '127.0.0.1,localhost,10.58.42.26,*')
CSRF_TRUSTED_ORIGINS = env_list('CSRF_TRUSTED_ORIGINS', '')

SITE_NAME = 'Axial Foundry'
SITE_URL = os.getenv('SITE_URL', 'http://127.0.0.1:8000').rstrip('/')
CONTACT_EMAIL = os.getenv('CONTACT_EMAIL', 'info@axialfoundary.com')
CONTACT_PHONE = os.getenv('CONTACT_PHONE', '+92 323 5809900')
CONTACT_LOCATION = os.getenv('CONTACT_LOCATION', 'Lahore, Pakistan')
LEADS_NOTIFICATION_EMAIL = os.getenv('LEADS_NOTIFICATION_EMAIL', CONTACT_EMAIL)
OWNER_PROFILE_URL = os.getenv('OWNER_PROFILE_URL', '').strip()

FOUNDER_NAME = 'Munief Hassan Tahir'
FOUNDER_TITLE = 'Senior Machine Learning Engineer — NLP & Speech AI'
FOUNDER_SUMMARY = (
    'Led by Munief Hassan Tahir, a machine learning engineer with 4+ years of experience '
    'across AI systems, software delivery, NLP, speech technologies, and production-grade '
    'Python engineering.'
)

RATE_LIMIT_WINDOW_SECONDS = int(os.getenv('RATE_LIMIT_WINDOW_SECONDS', '900'))
RATE_LIMIT_MAX_SUBMISSIONS = int(os.getenv('RATE_LIMIT_MAX_SUBMISSIONS', '5'))

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.sitemaps',
    'core',
    'leads',
    # ── Chatbot ───────────────────────────────────────────────
    'rest_framework',
    'corsheaders',
    'chatbot',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'axialfoundry.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'core.context_processors.site_settings',
            ],
        },
    },
]

WSGI_APPLICATION = 'axialfoundry.wsgi.application'
ASGI_APPLICATION = 'axialfoundry.asgi.application'

DATABASES = {
    'default': dj_database_url.config(
        default=f"sqlite:///{BASE_DIR / 'db.sqlite3'}",
        conn_max_age=600,
        conn_health_checks=True,
    )
}

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Karachi'
USE_I18N = True
USE_TZ = True

STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'
STORAGES = {
    'default': {
        'BACKEND': 'django.core.files.storage.FileSystemStorage',
    },
    'staticfiles': {
        'BACKEND': 'whitenoise.storage.CompressedManifestStaticFilesStorage',
    },
}

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

EMAIL_BACKEND = os.getenv('EMAIL_BACKEND', 'django.core.mail.backends.console.EmailBackend')
EMAIL_HOST = os.getenv('EMAIL_HOST', '')
EMAIL_PORT = int(os.getenv('EMAIL_PORT', '587'))
EMAIL_HOST_USER = os.getenv('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.getenv('EMAIL_HOST_PASSWORD', '')
EMAIL_USE_TLS = env_bool('EMAIL_USE_TLS', True)
EMAIL_USE_SSL = env_bool('EMAIL_USE_SSL', False)
DEFAULT_FROM_EMAIL = os.getenv('DEFAULT_FROM_EMAIL', 'studio@axialfoundry.local')
SERVER_EMAIL = DEFAULT_FROM_EMAIL

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'axial-foundry-cache',
    }
}

SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_REFERRER_POLICY = 'strict-origin-when-cross-origin'
X_FRAME_OPTIONS = 'DENY'
SESSION_COOKIE_HTTPONLY = True
CSRF_COOKIE_HTTPONLY = False
SESSION_COOKIE_SECURE = env_bool('SESSION_COOKIE_SECURE', not DEBUG)
CSRF_COOKIE_SECURE = env_bool('CSRF_COOKIE_SECURE', not DEBUG)
SECURE_SSL_REDIRECT = env_bool('SECURE_SSL_REDIRECT', False)
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': os.getenv('LOG_LEVEL', 'INFO'),
    },
    'loggers': {
        'chatbot': {
            'handlers': ['console'],
            'level': os.getenv('CHATBOT_LOG_LEVEL', 'INFO'),
            'propagate': False,
        },
    },
}

# ─── Chatbot ─────────────────────────────────────────────────────────────────────
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY', '')
CHATBOT_GEMINI_MODEL = os.getenv('CHATBOT_GEMINI_MODEL', 'gemini-2.5-flash')
CHATBOT_EMBED_MODEL = os.getenv('CHATBOT_EMBED_MODEL', 'all-MiniLM-L6-v2')
CHROMA_DB_PATH = BASE_DIR / 'chroma_db'
KNOWLEDGE_BASE_PATH = BASE_DIR / 'data' / 'knowledge_base.md'
CHATBOT_MAX_HISTORY_TURNS = int(os.getenv('CHATBOT_MAX_HISTORY_TURNS', '10'))
CHATBOT_RETRY_DELAY_SECONDS = int(os.getenv('CHATBOT_RETRY_DELAY_SECONDS', '30'))
CHATBOT_STATIC_FALLBACK_MSG = os.getenv(
    'CHATBOT_STATIC_FALLBACK_MSG',
    'I am having a brief technical issue. Please try again in a moment, or use the '
    'contact form below — I will get back to you shortly.',
)

# ─── CORS (open in DEBUG, otherwise restricted to the configured origins) ────────
CORS_ALLOWED_ORIGINS = env_list(
    'CORS_ALLOWED_ORIGINS',
    'https://axialfoundary.com,https://www.axialfoundary.com',
)
CORS_ALLOW_ALL_ORIGINS = DEBUG  # convenient for local development only

# ─── Django REST Framework ───────────────────────────────────────────────────────
REST_FRAMEWORK = {
    'DEFAULT_RENDERER_CLASSES': ['rest_framework.renderers.JSONRenderer'],
    'DEFAULT_THROTTLE_CLASSES': ['rest_framework.throttling.AnonRateThrottle'],
    'DEFAULT_THROTTLE_RATES': {'anon': '60/min'},
}
